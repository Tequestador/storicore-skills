# Skill: qa-agent-v0

## Purpose
Translate a bug report or risky change into a **tight reproduction + iPhone smoke plan** and a minimal fix strategy.

## Inputs
- issue description
- affected pages/components
- device/browser targets
- any logs/screenshots

## Outputs
- repro steps
- expected vs actual
- minimal fix plan (files + patch approach)
- verification commands + iPhone checklist pointers
