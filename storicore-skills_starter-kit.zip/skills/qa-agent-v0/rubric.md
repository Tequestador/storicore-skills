# Rubric (qa-agent-v0)

- Repro is unambiguous (0–2)
- Fix strategy is minimal (0–2)
- Verification is explicit (0–2)
- iPhone testing included (0–2)
- No refactor creep (0–2)

Pass: >= 8/10
