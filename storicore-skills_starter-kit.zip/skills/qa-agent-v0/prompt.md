# Prompt (Skill: qa-agent-v0)

Read `storicore-skills/AGENTS.md` first.

Input:
- Bug / risk:
- Where it shows up:
- Devices/browsers:
- Logs/snips:

Output format:
1) Repro steps (numbered)
2) Expected vs actual
3) Minimal fix strategy (files + approach)
4) Verification commands
5) iPhone smoke subset to run (Safari/Chrome)
