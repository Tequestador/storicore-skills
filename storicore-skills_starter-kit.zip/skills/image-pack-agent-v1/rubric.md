# Rubric (image-pack-agent-v1)

- Prompts are distinct but consistent (0–2)
- Camera/lighting is specified (0–2)
- Style bible respected (0–2)
- No unwanted invention (0–2)
- Easy to paste into a generator (0–2)

Pass: >= 8/10
