# Prompt (Skill: image-pack-agent-v1)

Read `storicore-skills/AGENTS.md` first.

Goal: generate a 4-prompt pack for a single Moment.

Inputs (fill these in):
- Moment:
- Aspect ratio:
- Style bible:
- Continuity constraints:
- Avoid list:

Output:
- Prompt A:
- Prompt B:
- Prompt C:
- Prompt D:
- Variation knobs (optional):
