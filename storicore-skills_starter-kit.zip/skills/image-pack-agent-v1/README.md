# Skill: image-pack-agent-v1

## Purpose
Turn one story Moment into a **4-prompt pack** that is consistent, production-ready, and easy to batch.

## When to use
- Nightcap image work
- Building prompt packs in Image Lab
- Preparing storyboard panels / graphic novel beats

## Inputs
- moment summary (1–5 sentences)
- aspect ratio
- style bible (project-level)
- continuity constraints (characters, location, time of day)

## Outputs
- 4 numbered prompts (A/B/C/D) with:
  - subject + action
  - environment + props
  - camera/framing + lighting
  - style tags
  - negative constraints (what to avoid)
- optional: “variation knobs” (1–2 per prompt)

## Constraints
- Must not invent new canon details without flagging them.
- Must respect style bible and continuity checklist.
