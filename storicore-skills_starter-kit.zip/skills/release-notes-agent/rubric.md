# Rubric (release-notes-agent)

- Accurate (0–2)
- User-readable (0–2)
- Clear impact (0–2)
- Mentions risks/rollback when needed (0–2)
- Not overly verbose (0–2)

Pass: >= 8/10
