# Prompt (Skill: release-notes-agent)

Read `storicore-skills/AGENTS.md` first.

Inputs:
- Version/tag:
- Audience:
- Changes (commits/PR summary):

Output:
- User-facing release notes (bullets)
- Dev notes (optional)
- Risk + rollback note
