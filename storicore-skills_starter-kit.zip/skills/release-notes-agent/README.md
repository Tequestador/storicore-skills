# Skill: release-notes-agent

## Purpose
Turn commits or a PR description into release notes that users can understand.

## Inputs
- PR summary or commit list
- target audience (users vs devs)
- version/tag

## Outputs
- user-facing notes (bullets)
- developer notes (optional)
- upgrade/rollback note
