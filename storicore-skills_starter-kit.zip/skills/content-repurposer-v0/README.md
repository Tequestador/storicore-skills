# Skill: content-repurposer-v0

## Purpose
Repurpose one devlog / update into:
- a short post
- a longer post outline
- an email draft
- a 30–60 second short script

## Inputs
- source text
- audience + platform
- CTA
- constraints (tone, length)

## Outputs
All four artifacts + suggested thumbnail/title ideas.
