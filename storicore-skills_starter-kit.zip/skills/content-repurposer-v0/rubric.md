# Rubric (content-repurposer-v0)

- Clarity and coherence (0–2)
- Matches tone constraints (0–2)
- Strong CTA (0–2)
- Reuses source faithfully (0–2)
- Outputs are ready to paste (0–2)

Pass: >= 8/10
