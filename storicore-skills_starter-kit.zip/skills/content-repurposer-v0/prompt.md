# Prompt (Skill: content-repurposer-v0)

Read `storicore-skills/AGENTS.md` first.

Inputs:
- Source text:
- Audience/platform:
- CTA:
- Tone constraints:

Output:
1) Short post (<=120 words)
2) Longer post outline (5 bullets)
3) Email draft (subject + body)
4) Short script (30–60s)
5) Thumbnail/title ideas (3)
