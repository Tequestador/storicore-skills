# Rubric (Skill: <name>)

Score 0–2 each:

- Scope discipline (0–2)
- Patch minimalism (0–2)
- Verification clarity (0–2)
- Readability / maintainability (0–2)
- Alignment with conventions (0–2)

Passing score: >= 8/10
