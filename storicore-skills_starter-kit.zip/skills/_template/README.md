# Skill: <name>

## Purpose
What this skill does.

## When to use
Triggers / contexts.

## Inputs
What you must provide.

## Outputs
What the agent must produce.

## Constraints / guardrails
No refactors, verification required, etc.

## Verification
Exact commands and pass criteria.

## Update history
What changed and why.
