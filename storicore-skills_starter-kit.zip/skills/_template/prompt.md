# Prompt (Skill: <name>)

You are an agent working in a STORiCORE repo.

Before doing anything:
1) Read `storicore-skills/AGENTS.md`
2) Follow `storicore-skills/playbooks/agent-first-wrapper.md`

Task:
- Goal:
- Context (repo/branch):
- Constraints:
- Definition of done:

Required output format:
1) Plan (files, steps, risks, verification)
2) Minimal patch (diffs)
3) Verification commands
4) Rollback note
