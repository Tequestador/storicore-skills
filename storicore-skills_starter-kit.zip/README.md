# storicore-skills (starter kit)

**Purpose:** a shared, versioned “compounding memory” for agentic work across STORiCORE projects.

This repo contains:
- **AGENTS.md**: global operating rules + quality bar (“no slop” gate)
- **playbooks/**: repeatable patterns aligned to your daily blocks (Learn / Build / Ship / Agents/CLI / Output)
- **checklists/**: fast smoke checks (especially iPhone) + PR review standards
- **skills/**: reusable agent skills (prompt + rubric + examples)
- **mcp/**: internal tool inventory + least-privilege guidance
- **evals/**: tiny regression cases to prevent backsliding
- **incidents/**: short writeups when an agent fails (so you harden the system)

## How to use in a project repo (recommended: submodule)

```bash
git submodule add <YOUR_GITHUB_URL>/storicore-skills.git storicore-skills
git commit -m "Add storicore-skills submodule"
```

Agents should be instructed to:
1) read `storicore-skills/AGENTS.md`
2) use an appropriate `storicore-skills/skills/<skill>/prompt.md`
3) follow the `playbooks/agent-first-wrapper.md` loop

## How to update (pull latest skills into a project)

```bash
git submodule update --remote --merge
git commit -am "Update storicore-skills"
```

_Last updated: 2026-02-07_
