# Agent-First Wrapper (use inside every block)

## Loop
1) **Instruction**: give the agent a single, scoped goal.
2) **Plan**: agent returns (files, steps, risks, verification).
3) **Patch**: agent produces minimal diff.
4) **Test**: run exact commands (fastest meaningful verification).
5) **Record**: commit + add/update a skill/checklist/regression case if needed.

## Stop rules
- If risky: reduce to one file / one function.
- If uncertain: ask for a logging probe or a tiny reproduction test.
- If the patch grows: split into two PRs.
