# Daily Blocks (aligned with your schedules)

## Learn (7:30–9:30 style blocks)
Agent must produce:
- 3 bullets: What / Why / How
- 1 micro-task you can do today that improves a skill/checklist/template

## Build (core feature)
Agent must produce:
- touched-file list
- minimal patch proposal
- exact verification commands

## Ship (small slice)
Agent must produce:
- one PR/commit plan
- smoke steps (2–5 mins)
- rollback note

## Agents/CLI (infrastructure)
Agent must produce:
- one reusable artifact committed here (skill or checklist)

## Output (nightcap)
Agent must produce:
- something visible: demo, screenshots, prompt packs, images, devlog draft, release note
