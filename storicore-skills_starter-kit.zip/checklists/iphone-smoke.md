# iPhone Smoke Checklist (Safari + Chrome)

Run this whenever you touch voice-to-chat, hydration, or rendering.

## Safari (iOS)
- Load app cold (new tab)
- Start voice session, speak 2 turns
- Navigate to Chat Workspace
- Confirm message order + missing lines
- Refresh Chat Workspace and verify persistence
- Check console overlay / debug mode if enabled

## Chrome (iOS)
Repeat same steps (Chrome uses WebKit but catches different UX issues).

## Pass criteria
- No reversed transcript
- No missing user lines
- No duplicated assistant lines
- Hydration picks up the correct active chat
