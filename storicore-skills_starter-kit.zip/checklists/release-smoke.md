# Release Smoke Checklist (10 minutes)

- [ ] Install / deploy / preview build succeeds
- [ ] Critical path works (login -> key page -> core action)
- [ ] Mobile quick pass (iPhone Safari)
- [ ] Error logging visible (Sentry/console)
- [ ] Rollback plan identified (tag / revert / previous deploy)
