# PR “No Slop” Review Checklist

- [ ] Clear goal (1–2 sentences)
- [ ] Small diff / reversible
- [ ] Verified with exact commands
- [ ] Risk + rollback included
- [ ] Readability: naming + comments where needed
- [ ] No hidden side-effects
- [ ] No “clever” abstractions without benefit
- [ ] Matches project conventions
