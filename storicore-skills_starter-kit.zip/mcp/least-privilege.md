# Least privilege defaults for agents

Start from read-only. Escalate only when necessary.

## Levels
1) Read-only: search, analyze, plan, propose diffs
2) Local write: patch files + run tests (no network side-effects)
3) Limited network: call a single endpoint with tight scopes
4) Deploy / prod changes: only with explicit human approval + rollback plan
