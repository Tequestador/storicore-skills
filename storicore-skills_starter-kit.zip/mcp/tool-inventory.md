# Tool inventory (agent-accessible)

List tools your workflows rely on, and how an agent should access them.

## Template
- Tool name:
- Purpose:
- Access method: CLI / HTTP / MCP server
- Inputs:
- Outputs:
- Rate limits:
- Secrets required:
- Safe defaults:
- Dangerous actions:
