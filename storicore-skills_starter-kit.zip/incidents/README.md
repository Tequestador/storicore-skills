# Incidents

When an agent fails, log it quickly so you can harden the system.

Use the template file naming:
`YYYY-MM-DD_short_slug.md`
