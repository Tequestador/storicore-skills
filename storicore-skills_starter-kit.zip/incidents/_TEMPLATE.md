# Incident: <short title>
Date:
Repo/branch:
Agent/tool:

## What happened (2–5 bullets)

## Root cause (best guess)

## Fix applied (link PR/commit)

## Prevent recurrence
- skill update:
- checklist update:
- regression case:
