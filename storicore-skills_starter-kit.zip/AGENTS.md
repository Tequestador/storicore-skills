# AGENTS.md (Global Rules for STORiCORE)

## Core principles
1) **Agent-first**: for any technical task, start with an agent instruction (Plan → Patch → Test → Iterate).
2) **Human accountability**: a human approves every merge/release.
3) **Surgical diffs**: prefer small, reversible changes. Avoid “drive-by refactors”.
4) **Fast verification**: run the fastest check that catches mistakes (typecheck / lint / unit / smoke).
5) **No slop**: code must be readable, maintainable, and aligned with existing patterns.

## Required outputs from agents (before code changes)
- **Scope**: 1-line goal + what is explicitly NOT being changed
- **Touched files list**
- **Proposed diff strategy** (where and why)
- **Verification commands** (exact commands; expected pass signal)
- **Rollback note** (what to revert if it fails)

## Safety + permissions defaults
- Start with **read-only** reasoning and planning.
- Do not request elevated permissions unless:
  - the change is clearly scoped, and
  - verification is defined, and
  - rollback is trivial.

## “When the agent struggles” rule
If an agent makes a wrong assumption, produces a broken build, or introduces confusing code:
1) Write an incident note in `incidents/` (2–10 minutes).
2) Update the relevant skill prompt OR add a checklist item OR add a regression case.
3) Re-run the smallest possible verification.

## Style requirements
- Use existing lint + formatting conventions.
- Prefer explicit names over cleverness.
- Any new helper must have a brief comment explaining intent.
- Keep side-effects obvious.

## PR review gate (“no slop”)
A PR must include:
- What changed + why
- How it was verified
- Screenshots / repro steps (if UI)
- Risk + rollback

If it’s “functionally correct but poorly maintainable”, it’s a **no**.
