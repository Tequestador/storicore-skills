# Regression: Mobile message ordering + missing lines

## Setup
- Use iPhone Safari
- Ensure fresh login

## Steps
1) Start voice conversation: speak 2 user turns, wait for assistant each time.
2) Navigate to Chat Workspace page.
3) Verify messages appear in chronological order and include all user lines.
4) Refresh Chat Workspace.
5) Verify ordering and completeness persist.

## Expected
- No reversed transcript
- No missing user lines
- No duplicates
