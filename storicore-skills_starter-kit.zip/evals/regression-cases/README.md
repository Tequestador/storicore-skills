# Regression cases

Short, repeatable “must not break” scenarios.
Each case should include:
- setup
- steps
- expected outcome
- logs to capture if failing
